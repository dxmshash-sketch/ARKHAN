# Slot Demo

Proyek demo game slot dengan **kredit virtual tanpa nilai uang**.

## Isi
- `slot-engine/` mesin slot di server (RNG crypto, 10 garis, wild, scatter, free spin), RTP sekitar 96%.
- `wallet-service/` kerangka seamless wallet untuk integrasi agregator (idempoten, HMAC, pembatas yurisdiksi).
- `prototype/` prototipe web mandiri (RNG di browser, hanya demo).

## Menjalankan
```
cd slot-engine
npm test
npm run simulate
PORT=8888 npm start
```
Buka `http://localhost:8888`.

## Catatan
- Data pemain disimpan di memori dan hilang saat server restart.
- Tidak untuk perjudian uang sungguhan. Penggunaan real-money memerlukan lisensi,
  sertifikasi lab penguji, KYC, dan pembatasan wilayah sesuai hukum setempat.
- Jangan commit secret (`AGG_SECRET`, kunci `.pem`). Gunakan variabel lingkungan.
