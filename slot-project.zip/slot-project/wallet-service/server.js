'use strict';
// Kerangka seamless wallet untuk integrasi agregator.
// Nama endpoint dan field asli mengikuti dokumentasi agregator setelah kontrak
// ditandatangani; ini adalah bentuk umum yang dipakai hampir semua agregator.
// Uang disimpan sebagai integer satuan terkecil (sen). Ganti Map dengan PostgreSQL
// (transaksi + row lock) sebelum produksi.
const http = require('node:http');
const crypto = require('node:crypto');

const SECRET = process.env.AGG_SECRET || 'ganti-dengan-secret-dari-agregator';
// Hanya negara yang tercakup lisensi Anda. Wajib diisi sesuai lisensi.
const ALLOWED = new Set((process.env.ALLOWED_COUNTRIES || 'SE,DK,ES,MT').split(','));
const LAUNCH_BASE = process.env.AGG_LAUNCH_BASE || 'https://agregator.example/launch';

const players = new Map([['demo', { balance: 100000, currency: 'EUR', country: 'SE', kyc: true }]]);
const txs = new Map(); // txId -> { type, playerId, amount, roundId, status, result }

function gate(p) {
  if (!p) return 'PLAYER_NOT_FOUND';
  if (!ALLOWED.has(p.country)) return 'JURISDICTION_BLOCKED';
  if (!p.kyc) return 'KYC_REQUIRED';
  return null;
}
const isMoney = (n, min) => Number.isInteger(n) && n >= min;

const routes = {
  '/wallet/balance': (b) => {
    const p = players.get(b.playerId), err = gate(p);
    return err ? { error: err } : { balance: p.balance, currency: p.currency };
  },

  '/wallet/bet': (b) => {
    const prev = txs.get(b.txId);
    if (prev) return prev.tombstone ? { error: 'ALREADY_ROLLED_BACK' } : prev.result; // idempoten
    const p = players.get(b.playerId), err = gate(p);
    if (err) return { error: err };
    if (!isMoney(b.amount, 1)) return { error: 'INVALID_AMOUNT' };
    if (p.balance < b.amount) return { error: 'INSUFFICIENT_FUNDS', balance: p.balance };
    p.balance -= b.amount;
    const result = { balance: p.balance, currency: p.currency };
    txs.set(b.txId, { type: 'bet', playerId: b.playerId, amount: b.amount, roundId: b.roundId, status: 'ok', result });
    return result;
  },

  '/wallet/win': (b) => {
    const prev = txs.get(b.txId);
    if (prev) return prev.result;
    const p = players.get(b.playerId);
    if (!p) return { error: 'PLAYER_NOT_FOUND' };
    if (!isMoney(b.amount, 0)) return { error: 'INVALID_AMOUNT' };
    const bet = [...txs.values()].find(t => t.type === 'bet' && t.roundId === b.roundId && t.playerId === b.playerId && t.status === 'ok');
    if (!bet) return { error: 'UNKNOWN_ROUND' };
    p.balance += b.amount; // kemenangan tetap dikreditkan walau pemain kini terblokir
    const result = { balance: p.balance, currency: p.currency };
    txs.set(b.txId, { type: 'win', playerId: b.playerId, amount: b.amount, roundId: b.roundId, status: 'ok', result });
    return result;
  },

  '/wallet/rollback': (b) => {
    const p = players.get(b.playerId);
    if (!p) return { error: 'PLAYER_NOT_FOUND' };
    const bet = txs.get(b.refTxId);
    if (!bet) { txs.set(b.refTxId, { tombstone: true, status: 'rolled_back' }); return { balance: p.balance, currency: p.currency }; }
    if (bet.status !== 'rolled_back') { p.balance += bet.amount; bet.status = 'rolled_back'; }
    return { balance: p.balance, currency: p.currency };
  },

  '/games/launch': (b) => {
    const p = players.get(b.playerId), err = gate(p);
    if (err) return { error: err };
    const token = crypto.randomBytes(16).toString('hex'); // di produksi: simpan sesi + kedaluwarsa
    return { url: `${LAUNCH_BASE}?game=${encodeURIComponent(b.gameId)}&token=${token}&lang=en` };
  },
};

function verify(raw, sig) {
  const mac = crypto.createHmac('sha256', SECRET).update(raw).digest('hex');
  const a = Buffer.from(mac), c = Buffer.from(String(sig || ''));
  return a.length === c.length && crypto.timingSafeEqual(a, c);
}

const server = http.createServer((req, res) => {
  const chunks = []; let size = 0;
  req.on('data', d => { size += d.length; if (size > 65536) req.destroy(); else chunks.push(d); });
  req.on('end', () => {
    const send = (code, obj) => { res.writeHead(code, { 'content-type': 'application/json' }); res.end(JSON.stringify(obj)); };
    const handler = req.method === 'POST' && routes[req.url];
    if (!handler) return send(404, { error: 'NOT_FOUND' });
    const raw = Buffer.concat(chunks);
    if (!verify(raw, req.headers['x-signature'])) return send(401, { error: 'BAD_SIGNATURE' });
    let body; try { body = JSON.parse(raw.toString() || '{}'); } catch { return send(400, { error: 'BAD_JSON' }); }
    send(200, handler(body));
  });
});

if (require.main === module) server.listen(process.env.PORT || 3000, () => console.log('wallet service aktif'));
module.exports = { server, SECRET };
