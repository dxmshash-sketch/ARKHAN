'use strict';
// Mesin slot sisi server. RNG memakai crypto (CSPRNG), tanpa modulo bias.
const crypto = require('node:crypto');

const CONFIG = {
  // id simbol: bobot kemunculan per posisi, pembayaran x3/x4/x5 (kelipatan taruhan per garis)
  symbols: {
    cherry:  { w: 22, pay: [5, 15, 40] },
    lemon:   { w: 22, pay: [5, 15, 40] },
    grape:   { w: 18, pay: [10, 30, 75] },
    bell:    { w: 14, pay: [17, 48, 118] },
    star:    { w: 10, pay: [25, 75, 200] },
    seven:   { w: 6,  pay: [50, 150, 500] },
    wild:    { w: 4,  pay: [75, 250, 1000] },
    scatter: { w: 3,  pay: null },
  },
  lines: [[1,1,1,1,1],[0,0,0,0,0],[2,2,2,2,2],[0,1,2,1,0],[2,1,0,1,2],
          [0,0,1,2,2],[2,2,1,0,0],[1,0,0,0,1],[1,2,2,2,1],[0,1,1,1,0]],
  freeSpins: { award: 8, multiplier: 2, scatterNeeded: 3 },
};

const IDS = Object.keys(CONFIG.symbols);
const TOTAL_W = IDS.reduce((a, id) => a + CONFIG.symbols[id].w, 0);

function randInt(n) {
  const lim = Math.floor(4294967296 / n) * n;
  const buf = new Uint32Array(1);
  let x;
  do { crypto.getRandomValues(buf); x = buf[0]; } while (x >= lim);
  return x % n;
}

function pickSymbol(rand = randInt) {
  let r = rand(TOTAL_W);
  for (const id of IDS) { r -= CONFIG.symbols[id].w; if (r < 0) return id; }
  return IDS[0];
}

const makeGrid = (rand = randInt) =>
  Array.from({ length: 5 }, () => [pickSymbol(rand), pickSymbol(rand), pickSymbol(rand)]);

// Mengembalikan total kelipatan (belum dikali taruhan per garis) dan garis yang menang.
function evaluate(grid) {
  let total = 0; const hits = [];
  CONFIG.lines.forEach((line, li) => {
    const seq = line.map((row, c) => grid[c][row]);
    if (seq.includes('scatter')) {
      // scatter memutus garis; hitung hanya bagian sebelum scatter
      seq.length = seq.indexOf('scatter');
    }
    let base = seq.find(s => s !== 'wild') ?? 'wild';
    let n = 0;
    for (const s of seq) { if (s === base || s === 'wild') n++; else break; }
    if (n >= 3 && CONFIG.symbols[base].pay) {
      const m = CONFIG.symbols[base].pay[n - 3];
      total += m; hits.push({ line: li, count: n, multiplier: m });
    }
  });
  return { total, hits };
}

const countScatter = grid => grid.flat().filter(s => s === 'scatter').length;

// state: { freeSpinsLeft }. Mengembalikan hasil satu putaran dan state baru.
function spin(state, lineBet, rand = randInt) {
  const free = state.freeSpinsLeft > 0;
  const grid = makeGrid(rand);
  const { total, hits } = evaluate(grid);
  const win = total * lineBet * (free ? CONFIG.freeSpins.multiplier : 1);
  let left = state.freeSpinsLeft - (free ? 1 : 0);
  let awarded = 0;
  if (countScatter(grid) >= CONFIG.freeSpins.scatterNeeded) { awarded = CONFIG.freeSpins.award; left += awarded; }
  return { grid, hits, win, free, awarded, state: { freeSpinsLeft: left } };
}

module.exports = { CONFIG, spin, evaluate, makeGrid, randInt, countScatter };
