'use strict';
// Mengukur RTP termasuk free spin. Pemakaian: node simulate.js [jumlahPutaranDasar]
const { spin, CONFIG } = require('./engine');
const N = +process.argv[2] || 2000000;
const LINE_BET = 1, COST = CONFIG.lines.length * LINE_BET;
let state = { freeSpinsLeft: 0 }, base = 0, wagered = 0, won = 0, wonFree = 0, triggers = 0, maxWin = 0, roundWin = 0;
while (base < N) {
  const r = spin(state, LINE_BET);
  if (!r.free) { base++; wagered += COST; maxWin = Math.max(maxWin, roundWin); roundWin = 0; }
  won += r.win; roundWin += r.win; if (r.free) wonFree += r.win; if (r.awarded) triggers++;
  state = r.state;
}
console.log(JSON.stringify({
  putaranDasar: N,
  RTP_total: +(won / wagered * 100).toFixed(2),
  RTP_dariFreeSpin: +(wonFree / wagered * 100).toFixed(2),
  frekuensiBonus: '1 per ' + Math.round(N / triggers) + ' putaran',
  kemenanganTerbesar_xTaruhan: +(maxWin / COST).toFixed(1),
}, null, 1));
