'use strict';
// Server putaran: hasil ditentukan di server, klien hanya menampilkan.
// Demo: kredit virtual, penyimpanan di memori. Produksi: database + log ronde permanen.
const http = require('node:http');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { spin, CONFIG } = require('./engine');

const BETS = [1, 2, 5];
const COST_LINES = CONFIG.lines.length;
const players = new Map(); // id -> { balance, state }
const roundLog = [];       // jejak audit tiap ronde

function getPlayer(id) {
  if (!players.has(id)) players.set(id, { balance: 1000, state: { freeSpinsLeft: 0 } });
  return players.get(id);
}

function doSpin(playerId, lineBet) {
  if (!BETS.includes(lineBet)) return { error: 'INVALID_BET' };
  const p = getPlayer(playerId);
  const cost = p.state.freeSpinsLeft > 0 ? 0 : lineBet * COST_LINES;
  if (p.balance < cost) return { error: 'INSUFFICIENT_FUNDS', balance: p.balance };
  p.balance -= cost;
  const r = spin(p.state, lineBet);
  p.state = r.state; p.balance += r.win;
  const roundId = crypto.randomUUID();
  roundLog.push({ roundId, playerId, lineBet, cost, win: r.win, grid: r.grid, free: r.free, at: Date.now() });
  return { roundId, grid: r.grid, hits: r.hits, win: r.win, free: r.free, freeSpinsAwarded: r.awarded,
           freeSpinsLeft: p.state.freeSpinsLeft, balance: p.balance };
}

const server = http.createServer((req, res) => {
  if (req.method === 'GET' && (req.url === '/' || req.url === '/index.html')) {
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
    return res.end(fs.readFileSync(path.join(__dirname, 'index.html')));
  }
  if (req.method === 'GET' && req.url === '/config') {
    const pays = Object.fromEntries(Object.entries(CONFIG.symbols).map(([k, v]) => [k, v.pay]));
    res.writeHead(200, { 'content-type': 'application/json' });
    return res.end(JSON.stringify({ bets: BETS, lines: COST_LINES, pays }));
  }
  const chunks = []; let size = 0;
  req.on('data', d => { size += d.length; if (size > 16384) req.destroy(); else chunks.push(d); });
  req.on('end', () => {
    const send = (c, o) => { res.writeHead(c, { 'content-type': 'application/json' }); res.end(JSON.stringify(o)); };
    let b = {}; try { b = JSON.parse(Buffer.concat(chunks).toString() || '{}'); } catch { return send(400, { error: 'BAD_JSON' }); }
    if (typeof b.playerId !== 'string' || !b.playerId) return send(400, { error: 'PLAYER_REQUIRED' });
    if (req.method === 'POST' && req.url === '/spin') return send(200, doSpin(b.playerId, b.lineBet));
    if (req.method === 'POST' && req.url === '/state') { const p = getPlayer(b.playerId); return send(200, { balance: p.balance, freeSpinsLeft: p.state.freeSpinsLeft }); }
    send(404, { error: 'NOT_FOUND' });
  });
});

if (require.main === module) server.listen(process.env.PORT || 3100, () => console.log('slot server aktif'));
module.exports = { server, doSpin };
