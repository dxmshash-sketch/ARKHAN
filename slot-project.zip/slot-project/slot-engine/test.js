'use strict';
const assert = require('node:assert');
const { spin, evaluate } = require('./engine');
const { doSpin } = require('./server');

// 1. Garis menang yang deterministik: 5 cherry di garis tengah = 40x
const g = [['lemon','cherry','lemon'],['lemon','cherry','lemon'],['lemon','cherry','lemon'],['lemon','cherry','lemon'],['lemon','cherry','lemon']];
assert.strictEqual(evaluate(g).hits.find(h => h.line === 0).multiplier, 40);
// 2. Scatter memutus garis: bell, wild lalu scatter hanya 2 simbol, jadi tidak menang
const w = [['bell','bell','bell'],['bell','wild','bell'],['bell','scatter','bell'],['bell','bell','bell'],['bell','bell','bell']];
assert.strictEqual(evaluate(w).hits.find(h => h.line === 0), undefined);
// Wild menggantikan simbol: bell, wild, bell, bell, bell = 5 bell
const w2 = [['x','bell','x'],['x','wild','x'],['x','bell','x'],['x','bell','x'],['x','bell','x']].map(c => c.map(s => s === 'x' ? 'lemon' : s));
assert.strictEqual(evaluate(w2).hits.find(h => h.line === 0).count, 5);
// 3. Free spin: tidak memotong saldo dan menggandakan kemenangan
const fixed = () => 0; // RNG palsu: selalu simbol pertama
const r = spin({ freeSpinsLeft: 1 }, 1, fixed);
assert.strictEqual(r.free, true); assert.strictEqual(r.state.freeSpinsLeft, 0);
// 4. Server: saldo konsisten
let bal = 1000;
for (let i = 0; i < 200; i++) {
  const o = doSpin('t', 1); assert.ok(!o.error);
  assert.ok(o.balance >= 0); bal = o.balance;
}
assert.ok(doSpin('t', 3).error === 'INVALID_BET');
console.log('semua tes lolos, saldo akhir', bal);
